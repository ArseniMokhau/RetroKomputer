package com.example.translatorapplication
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Invoke the magical function to set up the drawer
        setupNavigationDrawer()
    }

    // The sacred function to create the navigation drawer
    private fun setupNavigationDrawer() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)

        // Handle the selection of options with the ancient onNavigationItemSelectedListener
        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_information -> replaceFragment(InformationFragment())
                R.id.nav_basic_instructions -> replaceFragment(BasicInstructionsFragment())
                R.id.nav_advanced_instructions -> replaceFragment(AdvancedInstructionsFragment())
                R.id.nav_try_yourself -> replaceFragment(TryYourselfFragment())
            }

            // Close the drawer after selecting an option
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }

    // A mystical function to replace fragments within the sacred container
    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}